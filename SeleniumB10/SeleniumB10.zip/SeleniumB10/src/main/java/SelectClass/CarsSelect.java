package SelectClass;

import TestNG.utils.BrowserUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CarsSelect {
    //TAsk https://www.cars.com
    //Select new car- Porche -911
    //Click search button
    //Validate header is equals to " New Porsche 911 for sale

    @Test
    public void test() throws InterruptedException {
        ChromeDriver driver= new ChromeDriver();
        driver.get("https://www.cars.com/");

        WebElement newUsed=driver.findElement(By.xpath("//select[@id='make-model-search-stocktype']"));
        WebElement makes=driver.findElement(By.id("makes"));
        WebElement allmodels=driver.findElement(By.id("models"));
        WebElement submitButton= driver.findElement(By.xpath("//button[@data-linkname='search-new-make']"));


        BrowserUtils.selectBy(newUsed, "New cars", "text");
        BrowserUtils.selectBy(makes,"porsche","value");
        BrowserUtils.selectBy(allmodels,"4","index");

//        Select select = new Select(newUsed);
//        select.selectByVisibleText("New cars");
//
//        Select select1= new Select(makes);
//        select.selectByValue("porsche");
//
//        Select select2= new Select(allmodels);
//        select2.selectByIndex(4);
        submitButton.click();
        Thread.sleep(2000);

        WebElement header=driver.findElement(By.xpath("//h1"));
        String actual=BrowserUtils.getText(header);
        String expected =" New Porsche 911 for sale";
        Assert.assertEquals(actual,expected);








    }

}
