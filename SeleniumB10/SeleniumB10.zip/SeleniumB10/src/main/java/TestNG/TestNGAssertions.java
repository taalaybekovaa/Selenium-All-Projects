package TestNG;
public class TestNGAssertions {
}
