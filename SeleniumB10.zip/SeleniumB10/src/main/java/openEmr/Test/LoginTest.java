package openEmr.Test;

import com.test.sentrifugo.TestBase;

public class LoginTest extends TestBase {


}
